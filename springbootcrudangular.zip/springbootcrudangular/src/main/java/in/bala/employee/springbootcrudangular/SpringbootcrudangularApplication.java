package in.bala.employee.springbootcrudangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootcrudangularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootcrudangularApplication.class, args);
	}

}
